CREATE TABLE admin (
    username varchar(255) NOT NULL,
    password varchar(255) NOT NULL,
    PRIMARY KEY (username)
);

CREATE TABLE attendance (
                            id serial PRIMARY KEY,
                            courseCode varchar(255) NOT NULL,
                            regNumber varchar(255) NOT NULL,
                            "DATE" date DEFAULT NULL,
                            presence smallint NOT NULL,
                            FOREIGN KEY (courseCode) REFERENCES courses (code),
                            FOREIGN KEY (regNumber) REFERENCES student (regno)
);
;-- -. . -..- - / . -. - .-. -.--
CREATE TABLE attendance (
                            id serial PRIMARY KEY,
                            courseCode varchar(255) NOT NULL,
                            regNumber varchar(255) NOT NULL,
                            "DATE" date DEFAULT NULL,
                            presence smallint NOT NULL
);
;-- -. . -..- - / . -. - .-. -.--
INSERT INTO attendance (courseCode, regNumber, "DATE", presence) VALUES
                                                                     ('CSE2005', '1', '2020-04-01', 1),
                                                                     ('CSE2005', '1', '2020-04-02', 1),
                                                                     ('CSE2005', '1', '2020-04-03', 0),
                                                                     ('EVS2001', '1234', '2020-04-02', 1),
                                                                     ('EVS2001', '1', '2020-04-02', 0),
                                                                     ('EVS2001', '12345', '2020-04-02', 0),
                                                                     ('EVS2001', '1234', '2020-05-25', 1),
                                                                     ('EVS2001', '12345', '2020-05-25', 1),
                                                                     ('EVS2001', '1', '2020-05-25', 0);
;-- -. . -..- - / . -. - .-. -.--
CREATE TABLE classes (
                         courseCode varchar(255) NOT NULL,
                         regNumber varchar(255) NOT NULL
);
;-- -. . -..- - / . -. - .-. -.--
INSERT INTO classes (courseCode, regNumber) VALUES
                                                ('CSE2005', '1'),
                                                ('EVS2001', '1'),
                                                ('EVS2001', '1234'),
                                                ('EVS2001', '12345');
;-- -. . -..- - / . -. - .-. -.--
CREATE TABLE courses (
                         code varchar(255) NOT NULL,
                         name varchar(255) NOT NULL,
                         description varchar(255) NOT NULL,
                         credits varchar(255) NOT NULL,
                         type varchar(255) NOT NULL,
                         facUsername varchar(255) DEFAULT NULL
);
;-- -. . -..- - / . -. - .-. -.--
INSERT INTO courses (code, name, description, credits, type, facUsername) VALUES
                                                                              ('CSE2005', 'DD', 'DD', '1', 'Theory Only', ''),
                                                                              ('ECE1001', 'Electronics For Engineers', 'Electronics For Engineers.', '4', 'Lab Only', 'Abhinavgg'),
                                                                              ('EEE2001', 'Basic EEE', 'Very Basic', '3', 'Theory', 'Abhinavgg'),
                                                                              ('EVS2001', 'Environmental Sciences', 'EVS for kids', '2', 'Embedded', 'AbhinavF'),
                                                                              ('gdfgdgfd', 'dgdfgfdg', 'dfgdfg', '1', 'Theory Only', '');
;-- -. . -..- - / . -. - .-. -.--
CREATE TABLE faculty (
                         username varchar(255) NOT NULL,
                         fname varchar(255) NOT NULL,
                         lname varchar(255) NOT NULL,
                         email varchar(255) NOT NULL,
                         password varchar(255) NOT NULL,
                         phone varchar(255) NOT NULL
);
;-- -. . -..- - / . -. - .-. -.--
INSERT INTO faculty (username, fname, lname, email, password, phone) VALUES
                                                                         ('1', 'Someone', 'New', 'a@gmail.com', '1', '1234567890'),
                                                                         ('a1234', 'Acer', 'Preadator', 'dsa@sss.com', '123', '1234567890'),
                                                                         ('AbhinavF', 'AbhinavF', 'D', 'AbhinavF@gmail.com', '1', '1234567890'),
                                                                         ('Abhinavgg', 'Abhinavgg', 'Abhinavgg', 'Abhinav@gmail.com', '1', '1234567890'),
                                                                         ('cc', 'Siddhant', 'Dwivedi', 's@gmail.com', '123', '111');
;-- -. . -..- - / . -. - .-. -.--
CREATE TABLE student (
                         regno varchar(255) NOT NULL,
                         fname varchar(255) DEFAULT NULL,
                         lname varchar(255) DEFAULT NULL,
                         email varchar(255) NOT NULL,
                         phone varchar(255) NOT NULL,
                         address text NOT NULL,
                         "Branch" varchar(255) DEFAULT NULL,
                         password varchar(255) DEFAULT NULL
);
;-- -. . -..- - / . -. - .-. -.--
INSERT INTO student (regno, fname, lname, email, phone, address, "Branch", password) VALUES
                                                                                         ('1', 'FF', 'FF', 'f@gmail.com', '1111111111', 'FF1', 'CSE', '1'),
                                                                                         ('1234', 'PRANJAL', 'sharma', '1@gmail.com', '1111111111', '11', '111', '111'),
                                                                                         ('12345', 'ABHINAV', 'dhamaniya', 'a@gmail.com', '1111111111', '12', '121', '111'),
                                                                                         ('17BCE1121', 'ABHINAV', 'Dhamaniya', 'a@gmail.com', '123', '111', 'CSE', '123');
;-- -. . -..- - / . -. - .-. -.--
CREATE INDEX idx_attendance_id ON attendance (id);
;-- -. . -..- - / . -. - .-. -.--
CREATE UNIQUE INDEX idx_classes_course_reg ON classes (courseCode, regNumber);
;-- -. . -..- - / . -. - .-. -.--
CREATE UNIQUE INDEX idx_courses_code ON courses (code);
;-- -. . -..- - / . -. - .-. -.--
CREATE UNIQUE INDEX idx_faculty_username ON faculty (username);
;-- -. . -..- - / . -. - .-. -.--
CREATE UNIQUE INDEX idx_student_regno ON student (regno);
;-- -. . -..- - / . -. - .-. -.--
ALTER TABLE attendance
    ADD CONSTRAINT fk_attendance_courseCode
        FOREIGN KEY (courseCode)
            REFERENCES courses (code);
;-- -. . -..- - / . -. - .-. -.--
ALTER TABLE attendance
    ADD CONSTRAINT fk_attendance_regNumber
        FOREIGN KEY (regNumber)
            REFERENCES student (regno);
;-- -. . -..- - / . -. - .-. -.--
ALTER TABLE classes
    ADD CONSTRAINT fk_classes_courseCode
        FOREIGN KEY (courseCode)
            REFERENCES courses (code);
;-- -. . -..- - / . -. - .-. -.--
ALTER TABLE classes
    ADD CONSTRAINT fk_classes_regNumber
        FOREIGN KEY (regNumber)
            REFERENCES student (regno);
CREATE TABLE admin (
                       username varchar(255) NOT NULL,
                       password varchar(255) NOT NULL,
                       PRIMARY KEY (username)
);

ALTER TABLE courses
    ADD COLUMN adminUsername varchar(255) DEFAULT NULL,
    ADD CONSTRAINT fk_courses_adminUsername
        FOREIGN KEY (adminUsername) REFERENCES admin (username);

ALTER TABLE courses
    ADD COLUMN adminUsername varchar(255) DEFAULT NULL,
    ADD CONSTRAINT fk_courses_adminUsername
        FOREIGN KEY (adminUsername) REFERENCES admin (username);
