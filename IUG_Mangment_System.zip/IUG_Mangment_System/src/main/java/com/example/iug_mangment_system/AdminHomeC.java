package com.example.iug_mangment_system;

import javafx.event.ActionEvent;

import java.io.IOException;

public class AdminHomeC {


    public void manageCourses(ActionEvent event) throws IOException
    {
        SwitchScene s= new SwitchScene();
        s.changeSceneTo(event,"AdminManageCourses.fxml");
    }

    public void logout(ActionEvent event) throws IOException
    {
        LoggedInFaculty.logout();

        SwitchScene s = new  SwitchScene();
        s.changeSceneTo(event,"Homepage.fxml");
    }


}
