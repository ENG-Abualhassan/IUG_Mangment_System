package com.example.iug_mangment_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.*;

public class AdminLoginC {

    @FXML private TextField ausername, apassword;

    public void doLogin(ActionEvent e) throws IOException, SQLException, ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "850451hassan");

        String query= "SELECT * FROM admin WHERE username= username AND password = password";
        Statement st= con.createStatement();
        ResultSet rs= st.executeQuery(query);
        if(ausername.getText().equals("Usama") && apassword.getText().equals("12345"))
        {
            SwitchScene sw= new  SwitchScene();
            sw.changeSceneTo(e,"AdminHome.fxml");
        }else if(ausername.getText().equals("Ahmad") && apassword.getText().equals("54321"))
        {
            SwitchScene sw= new SwitchScene();
            sw.changeSceneTo(e,"AdminHome2.fxml");
        }
        else
        {
            Alert a= new Alert(Alert.AlertType.ERROR);
            a.setContentText("Invalid Admin Username/Password");
            a.show();
            System.out.println("Admin Login Failed.");
        }
    }

    public void back(ActionEvent e)throws IOException
    {
        SwitchScene sw= new  SwitchScene();
        sw.changeSceneTo(e,"Homepage.fxml");
    }

}
