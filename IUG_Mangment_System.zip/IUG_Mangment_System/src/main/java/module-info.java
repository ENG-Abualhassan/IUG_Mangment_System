module com.example.iug_mangment_system {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.postgresql.jdbc;
    requires java.naming;

    exports com.example.iug_mangment_system;
    opens com.example.iug_mangment_system to javafx.fxml;
}